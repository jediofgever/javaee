/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRODUCT;

import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 *
 * @author fet
 */
@Named(value = "imagebean")
@Dependent
public class imagebean {

    /**
     * Creates a new instance of imagebean
     */
    public imagebean() {
    }
    
     int image_id;
     String image_name;
     String product_name;

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }

    public String getImage_name() {
        return image_name;
    }

    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }
    
}
