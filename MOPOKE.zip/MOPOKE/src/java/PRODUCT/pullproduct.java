/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRODUCT;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
/**
 *
 * @author fet
 */
@Named(value = "pullproduct")
@Dependent
public class pullproduct {

    /**
     * Creates a new instance of pullproduct
     */
    public pullproduct() {
    }
      
         PreparedStatement ps=null;//SQL sorgumuzu tutacak ve çalıştıracak nesne.
        Connection con=null;//Veri tabanına bağlantı yapmamızı sağlayacak nesne.
        public List<products> getcustomerTable()throws ClassNotFoundException,SQLException{//Siz isterseniz try-catch yapısı ile yaparsınız.Hatta daha güzel olur bence.
            Class.forName("com.mysql.jdbc.Driver");//Hangi türde bir veri tabanını kullanacağını bildiriyoruz.
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");//Bağlanacağı veri tabanını ve kullanacağı kullanıcı adı-parolayı bildiriyoruz.
            ps=con.prepareStatement("SELECT * FROM products");//Yazarlar tablosundaki herşeyi çek diyoruz.
            ResultSet rs=ps.executeQuery();//SQL Sorgusundan dönecek sonuç rs sonuç kümesi içinde tutulacak.
            List<products> liste=new ArrayList<>();//AdiAlani sınıfı tipinde liste tanımladık çünkü SQL Sorgusundan dönecek sonuç içindeki Adi Alani kısmına bu tiple ulaşacaz.
            while(rs.next())//Kayıt olduğu sürece her işlem sonunda 1 satır atla.
            {
                products aa=new products();
                aa.setProduct_id(rs.getInt("product_id"));                                          //SQL Sorgusundan sütunları çekip bu değişkenin içinde Adı veya Alani kısmına atıyacağız.
                aa.setProduct_name(rs.getString("product_name"));
                aa.setSub_category_name(rs.getString("sub_category_name"));
                aa.setCategory_name(rs.getString("category_name"));
                aa.setCompany_name(rs.getString("company_name"));
                aa.setPrice(rs.getString("price"));
                aa.setSummary(rs.getString("summary"));
                aa.setTags(rs.getString("tags"));
                aa.setProduct_qty(rs.getString("product_qty"));
                aa.setLastUpdated(rs.getString("lastUpdated"));
                aa.setHits(rs.getString("hits"));
                
                
                
                liste.add(aa);//Her bir dönen sonucu listeye ekliyoruz.
            }
            System.out.print(rs);
        return liste;//Listeyi return ediyoruz.
        }
    
}
