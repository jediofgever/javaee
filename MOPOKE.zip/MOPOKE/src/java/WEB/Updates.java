/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WEB;


import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.*;

@ManagedBean(name="update")
@ViewScoped
public class Updates implements Serializable
{
    private static final long serialVersionUID = 1L;
    String text;
    Connection con;
    List<UserRegisterClass> liste=new ArrayList<>();
    
    public String getText() {
        return text;
    }
 
    public void setText(String text) {
        this.text = text;
    }
 
    public List<UserRegisterClass> getList()
    {
        return liste;
    }
 
    public String pullRecord()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            PreparedStatement ps=con.prepareStatement("SELECT * FROM User WHERE name LIKE ?");//İsme göre sorgu yapıyoruz.
            ps.setString(1, "%"+text+"%");//İsmin tamamını değil bir kısmını girseniz bile o kısmı içeren isimleri sorguya koyar.
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
           UserRegisterClass aa=new UserRegisterClass();
           aa.setID(rs.getInt("ID"));//Güncelleme için eşsiz alan lazım.ID bizim eşsiz alanımız.
           aa.setName(rs.getString("Name"));
           aa.setPassword(rs.getString("Password"));
           aa.setEmail(rs.getString("Email"));
           aa.setAddress(rs.getString("Address"));
           aa.setContactno(rs.getString("Contactno")); 
           aa.setGuncellenebilirlik(false);//İlk başta normal yazı halinde gelmesi için güncellenebilirlik kapalı.
           liste.add(aa);
            }
        }
        catch(Exception e)
        {
            System.err.println(e);
        }
       return null;
    }
    public String degisikligiKaydet() {
		for (UserRegisterClass userregisterclass : liste){
			userregisterclass.setGuncellenebilirlik(false);
		}
                //Kayıt güncellenince güncellenebilirliği tekrar kapatılır ve değişiklik işlenir.
		return null;
 
	}
    
    public boolean guncelle()//Güncellemeyi veri tabanına aktaracak metod.
    {
        int i=0;
        try{
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
        PreparedStatement ps=con.prepareStatement("UPDATE User SET Name=?,Password=?,Email=?,Address=?,Contactno=? WHERE ID=?");
           for(UserRegisterClass item:liste)
           //liste içindeki adı,alanı ve ID kısımlarını kullanmak için böyle bir döngü tanımladık. 
           {
            ps.setString(1, item.name);
            ps.setString(2, item.password);
            ps.setString(3, item.email);
            ps.setString(4, item.address);
            ps.setString(5, item.contactno);
            ps.setInt(6, item.ID);
            
           i= ps.executeUpdate();//İşlem  başarılı olursa i 0'dan büyük değer alır. Olmazsa küçük değer alır.
           }
        }
        catch(Exception e)
        {
            System.err.print(e);
        }
        if(i>0)
        return true;//İşlemin başarılı olması durumunda true döner.
        else
        return false;//Başarısız olma durumunda false döner.
    }
    public String guncellenebilirligiDegistir(UserRegisterClass a)
    {
        a.setGuncellenebilirlik(true);
        return null;
    }
}