package WEB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped

public class DatabaseClass {

	public DatabaseClass() {
	System.out.println("-----------------------------------------------------");
	System.out.println("-----------Database Class Constructor Called---------");
	System.out.println("-----------------------------------------------------");
	}
	
	/* ------------------------- Class Variables -----------------------------*/
	Connection connection = null;
	Statement statement =null;

	/* ------------------------- Database Connection Method -----------------------------*/
	public Connection getMySqlConnection() throws SQLException, ClassNotFoundException
	{
		 
		  
		  String driver = "com.mysql.jdbc.Driver";
		  String userName = "root"; 
		  String password = "";
		  String dbname="test";
		  Class.forName(driver);
		  String url = "jdbc:mysql://localhost:3306/"+dbname;
		  connection = DriverManager.getConnection(url, userName, password);
		  System.out.println("----------Connection URL: "+connection+"-------");
		return connection;
		
	}
	
	/* ------------------------- dbRegister Method -----------------------------*/
	public void dbRegister(String name, String password, String email, String contactno, String address)
	{
		try {
			String query="INSERT INTO User(Name,Password,Email,Contactno,Address)" +
				" VALUES('"+name+"','"+password+"','"+email+"','"+contactno+"','"+address+"')";
			connection=getMySqlConnection();
			statement=connection.createStatement();
			statement.executeUpdate(query);
			System.out.println("-------- Query :"+query+" -------------------");
			System.out.println("-------- Registration Done in User Table -------------------");
			statement.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
                
                
                
	}
        
      
        PreparedStatement ps=null;//SQL sorgumuzu tutacak ve çalıştıracak nesne.
        Connection con=null;//Veri tabanına bağlantı yapmamızı sağlayacak nesne.
        public List<UserRegisterClass> getcustomerTable()throws ClassNotFoundException,SQLException{//Siz isterseniz try-catch yapısı ile yaparsınız.Hatta daha güzel olur bence.
            Class.forName("com.mysql.jdbc.Driver");//Hangi türde bir veri tabanını kullanacağını bildiriyoruz.
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");//Bağlanacağı veri tabanını ve kullanacağı kullanıcı adı-parolayı bildiriyoruz.
            ps=con.prepareStatement("SELECT * FROM User");//Yazarlar tablosundaki herşeyi çek diyoruz.
            ResultSet rs=ps.executeQuery();//SQL Sorgusundan dönecek sonuç rs sonuç kümesi içinde tutulacak.
            List<UserRegisterClass> liste=new ArrayList<UserRegisterClass>();//AdiAlani sınıfı tipinde liste tanımladık çünkü SQL Sorgusundan dönecek sonuç içindeki Adi Alani kısmına bu tiple ulaşacaz.
            while(rs.next())//Kayıt olduğu sürece her işlem sonunda 1 satır atla.
            {
                UserRegisterClass aa=new UserRegisterClass();
                aa.setID(rs.getInt("id"));                                          //SQL Sorgusundan sütunları çekip bu değişkenin içinde Adı veya Alani kısmına atıyacağız.
                aa.setName(rs.getString("Name"));
                aa.setPassword(rs.getString("Password"));
                aa.setEmail(rs.getString("Email"));
                aa.setAddress(rs.getString("Address"));
                aa.setContactno(rs.getString("Contactno"));
                liste.add(aa);//Her bir dönen sonucu listeye ekliyoruz.
            }
            System.out.print(rs);
        return liste;//Listeyi return ediyoruz.
        }
                
        
}

