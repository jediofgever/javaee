package WEB;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;

import WEB.DatabaseClass;

@ManagedBean(name="user")
@SessionScoped
public class UserRegisterClass {
	
	public UserRegisterClass() {
		System.out.println("-----------------------------------------------------");
		System.out.println("-----UserRegister Default Constructor Called---------");
		System.out.println("-----------------------------------------------------");
	}

	/* ---------------------- Class Variables ---------------------- */
	String name;
	String password;
	String email;
	String address;
	String contactno;
        int ID;
        boolean guncellenebilirlik;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isGuncellenebilirlik() {
        return guncellenebilirlik;
    }

    public void setGuncellenebilirlik(boolean guncellenebilirlik) {
        this.guncellenebilirlik = guncellenebilirlik;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getContactno() {
        return contactno;
    }
    
    
    
    
	DatabaseClass obj=new DatabaseClass();
	
	/* ---------------------- Getters and Setters ---------------------- */

	/* ---------------------- Method call on Register Button ---------------------- */
	
	public String register()
	{
		System.out.println("----------- register Method Called ---------");
		try {
			obj.dbRegister(name, password, email, contactno, address);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "user?faces-redirect=true";
	}
        
        
      
       
        
        
}
