package WEB;

import javax.faces.bean.*;
import javax.faces.context.*;
import java.sql.*;
import java.util.Map;
import javax.inject.Named;
@ManagedBean
@ViewScoped
/**
 *
 * @author fet
 */
@Named(value = "delete")

public class delete {

	

   
    private int ID;
    Connection con;
    PreparedStatement ps;
    int i;
 
    public boolean deleterecord(){
 
		FacesContext fc = FacesContext.getCurrentInstance();
		this.ID = Integer.parseInt(IDParametresiniAl(fc));
                try{
                Class.forName("com.mysql.jdbc.Driver");
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
                ps=con.prepareStatement("DELETE FROM User WHERE ID=?");
                ps.setInt(1, ID);
                i=ps.executeUpdate();
                }
                catch(Exception e)
                {
                    System.out.print(e);
                }
                if(i>0)
                  
		    return true;
                else
                    return false;
	}
    public String IDParametresiniAl(FacesContext fc)
    {
        Map<String,String> parametreler = fc.getExternalContext().getRequestParameterMap();
		return parametreler.get("ID");
    }

 public boolean x() {
     
      if(i>0)
                  
		    return true;
                else
                    return false;
       
     }
}

