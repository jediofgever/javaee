/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import project.entities.Order;


/**
 *
 * @author HÊVÎ
 */
@Named(value = "orderBase")
@RequestScoped
public class OrderBaseClass {

    
    
    
    
    public OrderBaseClass() {
    }
    
    Connection connection = null;
    Statement statement =null;
    
    public Connection getMySqlConnection() throws SQLException, ClassNotFoundException
	{
		 
		  
		  String driver = "com.mysql.jdbc.Driver";
		  String userName = "root"; 
		  String password = "";
		  String dbname="test";
		  Class.forName(driver);
		  String url = "jdbc:mysql://localhost:3306/"+dbname;
		  connection = DriverManager.getConnection(url, userName, password);
		  System.out.println("----------Connection URL: "+connection+"-------");
		return connection;
		
	}
	
    
    
	/* ------------------------- dbRegister Method -----------------------------*/
	public void dbOrder( String orderer, String orderer_mail, String orderer_phone, String address,String cardno,String price,String shipper)
	{
		try {
                    
			String query="INSERT INTO `order`(`orderer`,orderer_mail,orderer_phone,address,cardno,price,shipper)" +
				" VALUES('"+orderer+"','"+orderer_mail+"','"+orderer_phone+"','"+address+"' ,'"+cardno+"','"+price+"','"+shipper+"')";
			connection=getMySqlConnection();
			statement=connection.createStatement();
			statement.executeUpdate(query);
			System.out.println("-------- Query :"+query+" -------------------");
			System.out.println("-------- e -------------------");
			statement.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
                
	}
        
        PreparedStatement ps=null;//SQL sorgumuzu tutacak ve çalıştıracak nesne.
        Connection con=null;//Veri tabanına bağlantı yapmamızı sağlayacak nesne.
        public List<Order> getorderTable()throws ClassNotFoundException,SQLException{//Siz isterseniz try-catch yapısı ile yaparsınız.Hatta daha güzel olur bence.
            Class.forName("com.mysql.jdbc.Driver");//Hangi türde bir veri tabanını kullanacağını bildiriyoruz.
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");//Bağlanacağı veri tabanını ve kullanacağı kullanıcı adı-parolayı bildiriyoruz.
            ps=con.prepareStatement("SELECT * FROM `order`");//Yazarlar tablosundaki herşeyi çek diyoruz.
            ResultSet rs=ps.executeQuery();//SQL Sorgusundan dönecek sonuç rs sonuç kümesi içinde tutulacak.
            List<Order> liste=new ArrayList<Order>();//AdiAlani sınıfı tipinde liste tanımladık çünkü SQL Sorgusundan dönecek sonuç içindeki Adi Alani kısmına bu tiple ulaşacaz.
            while(rs.next())//Kayıt olduğu sürece her işlem sonunda 1 satır atla.
            {
                Order aa=new Order();
                aa.setOrderId(rs.getInt("order_id"));  
                aa.setOrderer(rs.getString("orderer"));
                aa.setOrdererMail(rs.getString("orderer_mail"));
                aa.setOrdererPhone(rs.getString("orderer_phone"));
                aa.setAddress(rs.getString("address"));
                aa.setCardno(rs.getString("cardno"));
                aa.setPrice(rs.getString("price"));
                aa.setShipper(rs.getString("shipper"));
              
                liste.add(aa); 
            }
            System.out.print(rs);
        return liste; 
        }
                
        
}

    



