/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.web;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import project.entities.Music;

/**
 *
 * @author fet
 */
@ManagedBean
@RequestScoped
public class musicBean {

   
    
    Connection connection = null;
	Statement statement =null;

	/* ------------------------- Database Connection Method -----------------------------*/
	public Connection getMySqlConnection() throws SQLException, ClassNotFoundException
	{
		 
		  
		  String driver = "com.mysql.jdbc.Driver";
		  String userName = "root"; 
		  String password = "";
		  String dbname="test";
		  Class.forName(driver);
		  String url = "jdbc:mysql://localhost:3306/"+dbname;
		  connection = DriverManager.getConnection(url, userName, password);
		  System.out.println("----------Connection URL: "+connection+"-------");
		return connection;
		
	}
	
         PreparedStatement ps=null;//SQL sorgumuzu tutacak ve çalıştıracak nesne.
        Connection con=null;//Veri tabanına bağlantı yapmamızı sağlayacak nesne.
        
        public List<Music> getmusicTable()throws ClassNotFoundException,SQLException{//Siz isterseniz try-catch yapısı ile yaparsınız.Hatta daha güzel olur bence.
            Class.forName("com.mysql.jdbc.Driver");//Hangi türde bir veri tabanını kullanacağını bildiriyoruz.
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");//Bağlanacağı veri tabanını ve kullanacağı kullanıcı adı-parolayı bildiriyoruz.
            ps=con.prepareStatement("SELECT * FROM music");//Yazarlar tablosundaki herşeyi çek diyoruz.
            ResultSet rs=ps.executeQuery();//SQL Sorgusundan dönecek sonuç rs sonuç kümesi içinde tutulacak.
            List<Music> liste=new ArrayList<Music>();//AdiAlani sınıfı tipinde liste tanımladık çünkü SQL Sorgusundan dönecek sonuç içindeki Adi Alani kısmına bu tiple ulaşacaz.
            while(rs.next())//Kayıt olduğu sürece her işlem sonunda 1 satır atla.
            {
                Music aa=new Music();
                aa.setAlbumId(rs.getInt("album_id"));                                          //SQL Sorgusundan sütunları çekip bu değişkenin içinde Adı veya Alani kısmına atıyacağız.
                aa.setAlbumName(rs.getString("album_name"));
                aa.setSinger(rs.getString("singer"));
                aa.setPrice(rs.getDouble("price"));
                
                liste.add(aa);//Her bir dönen sonucu listeye ekliyoruz.
            }
            System.out.print(rs);
        return liste;//Listeyi return ediyoruz.
        }
        
    public musicBean() {
    }
    
    
    
    
    
    
}
