/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.web;


import WEB.*;
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.*;
import project.entities.Products;

@ManagedBean(name="updatepro")
@ViewScoped
public class updatesPro implements Serializable
{
    private static final long serialVersionUID = 1L;
    String text;
    Connection con;
    List<Products> liste=new ArrayList<>();
    
    public String getText() {
        return text;
    }
 
    public void setText(String text) {
        this.text = text;
    }
 
    public List<Products> getList()
    {
        return liste;
    }
 
    public String pullRecord()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            PreparedStatement ps=con.prepareStatement("SELECT * FROM Products WHERE product_name LIKE ?");//İsme göre sorgu yapıyoruz.
            ps.setString(1, "%"+text+"%");//İsmin tamamını değil bir kısmını girseniz bile o kısmı içeren isimleri sorguya koyar.
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
           Products aa=new Products();
           aa.setProductId(rs.getInt("product_id"));//Güncelleme için eşsiz alan lazım.ID bizim eşsiz alanımız.
           aa.setProductName(rs.getString("product_name"));
           aa.setPrice(rs.getDouble("price"));
           aa.setCategoryName(rs.getString("category_name"));
           aa.setTags(rs.getString("tags"));
           aa.setProductQty(rs.getInt("product_qty"));
           aa.setCompanyName(rs.getString("company_name"));
           aa.setHits(rs.getInt("hits"));
           aa.setLastUpdated(rs.getDate("lastUpdated"));
           aa.setSummary(rs.getString("summary"));
           aa.setSubCategoryName(rs.getString("sub_category_name"));
           aa.setGuncellenebilirlik(false);//İlk başta normal yazı halinde gelmesi için güncellenebilirlik kapalı.
           liste.add(aa);
            }
        }
        catch(Exception e)
        {
            System.err.println(e);
        }
       return null;
    }
    public String degisikligiKaydet() {
		for (Products products : liste){
			products.setGuncellenebilirlik(false);
		}
                //Kayıt güncellenince güncellenebilirliği tekrar kapatılır ve değişiklik işlenir.
		return null;
 
	}
    
    public boolean guncelle()//Güncellemeyi veri tabanına aktaracak metod.
    {
        int i=0;
        try{
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
        PreparedStatement ps=con.prepareStatement("UPDATE Products SET product_name=?,price=?category_name=?,tags=?, WHERE product_id=?");
           for(Products item:liste)
           //liste içindeki adı,alanı ve ID kısımlarını kullanmak için böyle bir döngü tanımladık. 
           {
            ps.setString(1, item.getProductName());
            ps.setDouble(2, item.getPrice());
            ps.setString(3, item.getCategoryName());
            ps.setString(4, item.getTags());
        
            ps.setInt(5, item.getProductId());
            
           i= ps.executeUpdate();//İşlem  başarılı olursa i 0'dan büyük değer alır. Olmazsa küçük değer alır.
           }
        }
        catch(Exception e)
        {
            System.err.print(e);
        }
        if(i>0)
        return true;//İşlemin başarılı olması durumunda true döner.
        else
        return false;//Başarısız olma durumunda false döner.
    }
    public String guncellenebilirligiDegistir(Products a)
    {
        a.setGuncellenebilirlik(true);
        return null;
    }
}