/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.web;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import project.ejbs.Operations;
import project.entities.Products;
import project.entities.Music;

/**
 *
 * @author fet
 */
@Named(value = "index")
@RequestScoped
public class index implements Serializable {

    @EJB
    private Operations operations;

    
    
    
    /**
     * Creates a new instance of index
     */
    public index() {
    }
    
    
    
    public List<Products> getProducts() {
        return operations.rertrieveProducts();
    }   
    
    
    public List<Music>    getMusic () {
        return operations.rertrieveMusic();
    }
}

