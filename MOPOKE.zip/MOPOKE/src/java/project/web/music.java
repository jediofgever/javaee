/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import project.ejbs.Operations;
import project.entities.Music;


/**
 *
 * @author fet
 */
@Named(value = "music")
@RequestScoped
public class music {

    @EJB
    private Operations operations;
  
   
    
    
    @ManagedProperty(value = "#(cart)")
    cart myCart;

    public cart getMyCart() {
        return myCart;
    }

    public void setMyCart(cart myCart) {
        this.myCart = myCart;
    }
    
    
    

    /**
     * Creates a new instance of music
     */
    public music() {
    }

  public String getQuery1() {

        return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("query1");

    }
   
  
  
   public void checkIfQueryExistsm() throws IOException {

        if (operations.checkIfQueryExistsm(getQuery1()) == 0) {

            FacesContext.getCurrentInstance().getExternalContext().redirect("error.xhtml");

        }

    }
  
  
  
  
  public Music getMusic() {

        return operations.returnMusic(getQuery1());

    }
       
  
  
  public void addToCartm() {

        String query1 = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("query1");

        myCart.addm(operations.returnMusic(query1));
    }
       
  
  
}
