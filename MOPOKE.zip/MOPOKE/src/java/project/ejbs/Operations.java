/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.ejbs;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import project.entities.Music;
import project.entities.Products;

/**
 *
 * @author fet
 */
@Stateless
public class Operations {

    @PersistenceContext(unitName = "registerPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    
    public List<Products> rertrieveProducts() {
        
        return  em.createQuery("SELECT p FROM Products p").getResultList();
    }
 
     public List<Music> rertrieveMusic() {
        
        return  em.createQuery("SELECT m FROM Music m").getResultList();
    }

   
      public int checkIfQueryExistsm(String query1){
        List<Music> music = em.createQuery("SELECT m FROM Music m WHERE m.albumName = :albumName").setParameter("albumName", query1).getResultList();
               
        return music.size();
     
                }
     

    public int checkIfQueryExists(String query){
        List<Products> products = em.createQuery("SELECT p FROM Products p WHERE p.productName = :productName").setParameter("productName", query).getResultList();
               
        return products.size();
               
                
                }
    
    public Products returnProduct(String query){
        
        Products product = (Products)em.createQuery("SELECT p FROM Products p WHERE p.productName = :productName").setParameter("productName", query).getSingleResult();
        
        return product;
    }
    
     public Music returnMusic(String query1){
        
        Music music = (Music)em.createQuery("SELECT m FROM Music m WHERE m.albumName = :albumName").setParameter("albumName", query1).getSingleResult();
        
        return music;
    }
    
    
}
