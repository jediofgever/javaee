
package project.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author fet
 */
@Entity
@Table(name = "music")
@NamedQueries({
    @NamedQuery(name = "Music.findAll", query = "SELECT m FROM Music m"),
    @NamedQuery(name = "Music.findByAlbumId", query = "SELECT m FROM Music m WHERE m.albumId = :albumId"),
    @NamedQuery(name = "Music.findByAlbumName", query = "SELECT m FROM Music m WHERE m.albumName = :albumName"),
    @NamedQuery(name = "Music.findBySinger", query = "SELECT m FROM Music m WHERE m.singer = :singer"),
    @NamedQuery(name = "Music.findByPrice", query = "SELECT m FROM Music m WHERE m.price = :price")})
public class Music implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "album_id")
    private Integer albumId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "album_name")
    private String albumName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "singer")
    private String singer;
    @Basic(optional = false)
    @NotNull
    @Column(name = "price")
    private double price;

    public Music() {
    }

    public Music(Integer albumId) {
        this.albumId = albumId;
    }

    public Music(Integer albumId, String albumName, String singer, double price) {
        this.albumId = albumId;
        this.albumName = albumName;
        this.singer = singer;
        this.price = price;
    }

    public Integer getAlbumId() {
        return albumId;
    }

    public void setAlbumId(Integer albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (albumId != null ? albumId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Music)) {
            return false;
        }
        Music other = (Music) object;
        if ((this.albumId == null && other.albumId != null) || (this.albumId != null && !this.albumId.equals(other.albumId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "project.entities.Music[ albumId=" + albumId + " ]";
    }
    
}
