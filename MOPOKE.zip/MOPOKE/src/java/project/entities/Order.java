/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.entities;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import cash.OrderBaseClass;
import javax.faces.bean.SessionScoped;


@ManagedBean(name="order")
@SessionScoped
@Table(name = "order")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Order.findAll", query = "SELECT o FROM Order o"),
    @NamedQuery(name = "Order.findByOrderId", query = "SELECT o FROM Order o WHERE o.orderId = :orderId"),
    @NamedQuery(name = "Order.findByOrderer", query = "SELECT o FROM Order o WHERE o.orderer = :orderer"),
    @NamedQuery(name = "Order.findByOrdererMail", query = "SELECT o FROM Order o WHERE o.ordererMail = :ordererMail"),
    @NamedQuery(name = "Order.findByOrdererPhone", query = "SELECT o FROM Order o WHERE o.ordererPhone = :ordererPhone"),
    @NamedQuery(name = "Order.findByAddress", query = "SELECT o FROM Order o WHERE o.address = :address"),
    @NamedQuery(name = "Order.findByCardno", query = "SELECT o FROM Order o WHERE o.cardno = :cardno"),
    @NamedQuery(name = "Order.findByPrice", query = "SELECT o FROM Order o WHERE o.price = :price"),
    @NamedQuery(name = "Order.findByShipper", query = "SELECT o FROM Order o WHERE o.shipper = :shipper")})
public class Order implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "order_id")
    private Integer orderId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "orderer")
    private String orderer;
    @Size(max = 25)
    @Column(name = "orderer_mail")
    private String ordererMail;
    @Size(max = 25)
    @Column(name = "orderer_phone")
    private String ordererPhone;
    @Size(max = 50)
    @Column(name = "address")
    private String address;
    @Size(max = 25)
    @Column(name = "cardno")
    private String cardno;
    @Size(max = 255)
    @Column(name = "price")
    private String price;
    @Size(max = 25)
    @Column(name = "shipper")
    private String shipper;

    public Order() {
    }

    public Order(Integer orderId) {
        this.orderId = orderId;
    }

    public Order(Integer orderId, String orderer) {
        this.orderId = orderId;
        this.orderer = orderer;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderer() {
        return orderer;
    }

    public void setOrderer(String orderer) {
        this.orderer = orderer;
    }

    public String getOrdererMail() {
        return ordererMail;
    }

    public void setOrdererMail(String ordererMail) {
        this.ordererMail = ordererMail;
    }

    public String getOrdererPhone() {
        return ordererPhone;
    }

    public void setOrdererPhone(String ordererPhone) {
        this.ordererPhone = ordererPhone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getShipper() {
        return shipper;
    }

    public void setShipper(String shipper) {
        this.shipper = shipper;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (orderId != null ? orderId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Order)) {
            return false;
        }
        Order other = (Order) object;
        if ((this.orderId == null && other.orderId != null) || (this.orderId != null && !this.orderId.equals(other.orderId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "project.entities.Order[ orderId=" + orderId + " ]";
    }
    
    OrderBaseClass obj=new OrderBaseClass();
    public String order()
	{
		System.out.println("----------- order Method Called ---------");
		try {
			obj.dbOrder(orderer, ordererMail, ordererPhone,  address,cardno,price,shipper);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "success.xhtml";
	}
}
